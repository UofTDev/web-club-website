$(document).ready(function () {

	// array to keep track of the board
	var board = [['','',''],
				 ['','',''],
				 ['','','']];

	// variable to indicate player's turn
	var playerTurn = 1;

	// indicates whether the game is over
	var isGameOver = false;

	// player clicks on a square
	$('.box').click(function() {
		if ($(this).data('set') != true && !isGameOver) {
			if (playerTurn == 1) {
				$(this).html('<div class="X"></div>');
				board[$(this).data('row')][$(this).data('column')] = 'X';
				playerTurn = 2;
			}
			else {
				$(this).html('<div class="O"></div>');
				board[$(this).data('row')][$(this).data('column')] = 'O';
				playerTurn = 1;
			}
			$(this).data('set', true);
			detectWin();
		}
	});

	// check if someone won
	function detectWin () {
		if (board[0][0] == board[0][1] && board[0][1] == board[0][2] && board[0][0] != '') {
			// first row
			gameOver(board[0][0]);
		}
		else if (board[1][0] == board[1][1] && board[1][1] == board[1][2] && board[1][0] != '') {
			// second row
			gameOver(board[1][0]);
		}
		else if (board[2][0] == board[2][1] && board[2][1] == board[2][2] && board[2][0] != '') {
			// third row
			gameOver(board[2][0]);
		}
		else if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != '') {
			// first diagonal
			gameOver(board[0][0]);
		}
		else if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != '') {
			// second diagonal
			gameOver(board[0][2]);
		}
	}

	function gameOver (winningPlayer) {
		isGameOver = true;
		alert('Game over! Player ' + winningPlayer + ' wins!');
	}
});