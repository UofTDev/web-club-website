//
//  SimpleBrowserAppDelegate.h
//  SimpleBrowser
//
//  Created by Owner on 12-11-11.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpleBrowserAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
