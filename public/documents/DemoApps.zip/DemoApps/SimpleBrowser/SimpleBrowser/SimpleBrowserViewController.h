//
//  SimpleBrowserViewController.h
//  SimpleBrowser
//
//  Created by Owner on 12-11-11.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpleBrowserViewController : UIViewController<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *txtAddress;
@property (weak, nonatomic) IBOutlet UITextView *txtResult;

@end
