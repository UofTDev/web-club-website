//
//  SimpleBrowserViewController.m
//  SimpleBrowser
//
//  Created by Owner on 12-11-11.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SimpleBrowserViewController.h"

@interface SimpleBrowserViewController ()

@end

@implementation SimpleBrowserViewController
@synthesize txtAddress;
@synthesize txtResult;
- (IBAction)btnGo {
    NSString *websiteAddress = [NSString stringWithString:self.txtAddress.text];
    NSLog(@"Address: %@",websiteAddress);
    NSURL *websiteURL = [NSURL URLWithString:websiteAddress];
    
    // Make asynchronous request
    NSURLRequest *req = [NSURLRequest requestWithURL:websiteURL];
    [NSURLConnection sendAsynchronousRequest:req queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        NSString *result = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSLog(@"Result: %@ - Error: %@",result,error);
        txtResult.text = result;
    }];
    
    // Make synchronous request
    /*
     NSString *result = [NSString stringWithContentsOfURL:websiteURL];
     NSLog(@"Result: %@",result);
     txtResult.text = result;
    */
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.txtAddress.delegate = self;
}

- (void)viewDidUnload
{
    [self setTxtAddress:nil];
    [self setTxtResult:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (BOOL)textFieldShouldReturn:(UITextField *)theTextField {
    if (theTextField == self.txtAddress) {
        [theTextField resignFirstResponder];
    }
    return YES;
}

@end
