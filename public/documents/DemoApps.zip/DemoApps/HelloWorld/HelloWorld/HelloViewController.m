//
//  HelloViewController.m
//  HelloWorld
//
//  Created by Owner on 12-11-19.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "HelloViewController.h"

@interface HelloViewController ()

@end

@implementation HelloViewController
@synthesize txtName;
@synthesize lblHello;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// This is important so we can handle the event when the user hit the return button in the keyboard which is neccessary to hide the keyboard.
    txtName.delegate = self;
}

- (void)viewDidUnload
{
    [self setTxtName:nil];
    [self setLblHello:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
- (IBAction)btnHelloAction {
    // Get the value from the txtName
    NSString* name = txtName.text;
    
    // Set the value in the lblHello with the word Hello the the name
    
    /* Create a String with format "%@ %@" and pass to it two parameters to replace each "%@" in order. First parameter is the word "Hello, second parameter is the name
    */
    
    lblHello.text = [NSString stringWithFormat:@"%@, %@",@"Hello",name];
    
    // To hide the keyboard from the txtName
    [txtName resignFirstResponder];
    
}

// This method to hide the keyboard after the user click return button in the keyboard
-(BOOL) textFieldShouldReturn:(UITextField *) textField {
    if(textField == txtName){
        
        // As further enhancement, we can call the button action when the user hit return button in the keyboard. Remove the below comment and see the different in the app
        
        //[self btnHelloAction];
        
        [textField resignFirstResponder];
    }
    return NO;
    
}
@end
