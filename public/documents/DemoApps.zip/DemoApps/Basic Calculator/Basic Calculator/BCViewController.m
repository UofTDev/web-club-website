//
//  BCViewController.m
//  Basic Calculator
//
//  Created by Francis Lata on 2012-11-05.
//  Copyright (c) 2012 Francis Lata. All rights reserved.
//

#import "BCViewController.h"

@interface BCViewController ()

// Outlets
@property (weak, nonatomic) IBOutlet UITextField *firstNumberTextField;
@property (weak, nonatomic) IBOutlet UITextField *secondNumberTextField;
@property (weak, nonatomic) IBOutlet UITextField *resultTextField;

// Current expression
@property (nonatomic, strong) BCExpression *currentExpression;

@end

@implementation BCViewController

- (IBAction)setOperation:(UIButton *)sender
{
    // [self.currentExpression setOperation]
    self.currentExpression.operation = sender.titleLabel.text;
}

- (IBAction)calculateResult:(id)sender
{
    self.currentExpression.firstNumber = [self.firstNumberTextField.text integerValue];
    self.currentExpression.secondNumber = [self.secondNumberTextField.text integerValue];
    self.resultTextField.text = [NSString stringWithFormat:@"Result: %d", [self.currentExpression calculateExpression]];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    // function1();
    self.currentExpression = [[BCExpression alloc] init];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
