//
//  BCAppDelegate.h
//  Basic Calculator
//
//  Created by Francis Lata on 2012-11-05.
//  Copyright (c) 2012 Francis Lata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
