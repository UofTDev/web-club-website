//
//  BCExpression.m
//  Basic Calculator
//
//  Created by Francis Lata on 2012-11-05.
//  Copyright (c) 2012 Francis Lata. All rights reserved.
//

#import "BCExpression.h"

@implementation BCExpression

@synthesize firstNumber, secondNumber, operation;

- (NSInteger)calculateExpression
{
    if ([self.operation isEqualToString:@"+"]) {
        return self.firstNumber + self.secondNumber;
    } else if ([self.operation isEqualToString:@"-"]) {
        return self.firstNumber - self.secondNumber;
    } else if ([self.operation isEqualToString:@"*"]) {
        return self.firstNumber * self.secondNumber;
    } else if ([self.operation isEqualToString:@"/"]) {
        return self.firstNumber / self.secondNumber;
    } else {
    return 0;
        }
}

@end
