//
//  Weather.m
//  iWeather
//
//  Created by Owner on 12-11-19.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Weather.h"

@implementation Weather

static NSArray* cities;
static NSArray* cityCode;
static NSString* weatherURL = @"http://weather.yahooapis.com/forecastrss?w=%@&u=%@";
bool forecastFound = NO;

@synthesize todayLow = _todayLow, todayHigh = _todayHigh, description = _description,feelsLike = _feelsLike;

+(void) initCities{
    cities = [[NSArray alloc] initWithObjects:@"Toronto", @"Calgary", @"Montreal", nil];
    
    cityCode = [[NSArray alloc] initWithObjects:@"4118", @"8775", @"3534", nil];
}

+(NSInteger) numberOfCities{
    if(!cities){
        [self initCities];
    }
    return[cities count];
}

+(NSString*) cityAtIndex:(NSInteger)index{
    if(!cities){
        [self initCities];
    }
    return [cities objectAtIndex:index];
}

-(void) tempratureForCity:(NSInteger)cityIndex withUnit:(NSString*)unit {
    
    id code = [cityCode objectAtIndex:cityIndex];
    
    NSString *urlString = [NSString stringWithFormat:weatherURL,code,unit];
    
    NSLog(@"%@",urlString);
    
    NSURL *url = [NSURL URLWithString:urlString];
    
    NSXMLParser *parser = [[NSXMLParser alloc] initWithContentsOfURL:url];
    
    parser.delegate = self;
    
    // a flag that help to recognize the first forecast (for today) and ignore the rest
    forecastFound = NO;
    
    [parser parse];

}
//wind:chill, atmosphere:humidity, forecast:low/high/text
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    // To store only the weather for today and ignore further forecasts
    if(!forecastFound){
        if([elementName isEqualToString:@"yweather:wind"]){
            _feelsLike = [[attributeDict objectForKey:@"chill"] intValue];  
        } else if([elementName isEqualToString:@"yweather:forecast"]){
            _todayLow = [[attributeDict objectForKey:@"low"] intValue];
            _todayHigh = [[attributeDict objectForKey:@"high"] intValue];
            _description = [attributeDict objectForKey:@"text"];
            forecastFound = YES;
        }
    }
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    
}
@end