//
//  WeatherViewController.m
//  iWeather
//
//  Created by Owner on 12-11-19.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "WeatherViewController.h"

@interface WeatherViewController ()

@end

@implementation WeatherViewController
@synthesize pickerCity;
@synthesize lblLow;
@synthesize lblHigh;
@synthesize lblFeelsLike;
@synthesize lblCondition;
@synthesize switchUnit;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [pickerCity setDelegate:self];
    [pickerCity setDataSource:self];
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setPickerCity:nil];
    [self setLblLow:nil];
    [self setLblHigh:nil];
    [self setLblFeelsLike:nil];
    [self setLblCondition:nil];
    [self setSwitchUnit:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)numberOfComponentsInPickerView:
(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView
numberOfRowsInComponent:(NSInteger)component
{
    return [Weather numberOfCities];
}
- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    return [Weather cityAtIndex:row];
} 

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    [self updateWeatherWithIndex:row];
}

-(void) updateWeatherWithIndex:(NSInteger) row {
    NSString* unit = @"c";
    if(self.switchUnit.on){
        unit = @"f";
    }
    Weather *weather =[[Weather alloc] init];
    [weather tempratureForCity:row withUnit:unit];
    lblLow.text = [NSString stringWithFormat:@"%d",weather.todayLow];
    lblHigh.text = [NSString stringWithFormat:@"%d",weather.todayHigh];
    lblFeelsLike.text = [NSString stringWithFormat:@"%d",weather.feelsLike];
    lblCondition.text = weather.description;
}
@end
