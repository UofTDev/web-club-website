//
//  Weather.h
//  iWeather
//
//  Created by Owner on 12-11-19.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Weather : NSObject<NSXMLParserDelegate>

@property (nonatomic) int todayLow;
@property (nonatomic) int todayHigh;
@property (weak, nonatomic) NSString *description;
@property (nonatomic) int feelsLike;

// Returns total number of cities to be used by the pickerView
+(NSInteger) numberOfCities;

// Returns the city title atIndex to be used by the pickerView
+(NSString*) cityAtIndex:(NSInteger)index;

// cityIndex is used to retreive the cityCode which is recognized by Yahoo
// weather API. the unit is 'c' or 'f'
// the method will call Yahoo api, parse the xml and retain important variables
-(void) tempratureForCity:(NSInteger)cityIndex withUnit:(NSString*) unit;
@end
